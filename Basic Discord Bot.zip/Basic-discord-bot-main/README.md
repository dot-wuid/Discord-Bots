# Basic-discord-bot

Has Code/files for wuidBot (my discord bot)
you should check it out ngl

https://dsc.gg/mcarchive


# Commands

- /hello (hello)
- /welcome_embed (makes a basic welcome embed)
- /add (adds two sums together VERY BASIC)
- /ping (gets bot ping)
- /bothelp (gets bot info such as support server, and invite link)
- /info (info about the bot, and the code who its by.)

# Copyright
i dont care if you credit me or not in the code, but just dont make a bad bot, like one of those Member Boosting ones...
Just dont do anything bad with it.
